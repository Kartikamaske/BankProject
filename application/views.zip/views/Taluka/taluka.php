
        <!-- =============== Left side End ================-->
        <div class="main-content-wrap sidenav-open d-flex flex-column">
            <!-- ============ Body content start ============= -->
            <div class="main-content">
                <div class="breadcrumb">
                    <h1>Taluka</h1>
                
                </div>
                <div class="separator-breadcrumb border-top"></div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card mb-4">
                            <div class="card-body">
                                <form role="form" id="Form" action="" method="post">
                                    <div class="row">

                              
                                      
                                        <div class="col-md-3 form-group mb-3">
                                            <label for="picker1">Country</label>
                                            <select class="form-control" name="fkcountry">
                                                <option value="1">India</option>
                                              
                                            </select>
                                        </div>

                                        <div class="col-md-3 form-group mb-3">
                                            <label for="picker1">State</label>
                                            <select class="form-control" name="fkstate">
                                                <option value="1">Maharashtra</option>
                                                <option value="1">Gujarat</option>
                                                <option value="1">Kerala</option>
                                                <option value="1">Chattisgarh</option>
                                              
                                            </select>
                                        </div>

                                        <div class="col-md-3 form-group mb-3">
                                            <label for="picker1">District</label>
                                            <select class="form-control" name="fkdist">
                                                <option value="1">Sangli</option>
                                                <option value="1">Satara</option>
                                                <option value="1">Kolhapur</option>
                                                <option value="1">Pune</option>
                                              
                                            </select>
                                        </div>


                                        <div class="col-md-3 form-group mb-3">
                                            <label for="talname">Taluka name</label>
                                            <input class="form-control" id="taluka" type="text" placeholder="Enter taluka name" name="taluka" value="" />
                                        </div>
                                       
                                      
                                     
                                        
                                        
                                        
                                     
                                        <div class="col-md-12">
                                            <button class="btn btn-primary" type="button" name="btn_save" id="btn_save">Submit</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
</div>
                  

<script  src="<?php echo base_url('web_resources');?>/dist/js/jquery.min.js"></script>          
<script  src="<?php echo base_url('web_resources');?>/dist/js/controllers/StudentCreate.js"></script>
                   
                       
               
            