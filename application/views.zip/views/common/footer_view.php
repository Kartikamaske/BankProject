<style>
    .app-footer{
        background-image: linear-gradient(225deg, white 50%, #1d458e 50%)!important;
    }
    @media(max-width:500px){
        .com{
            font-size:11px!important
        }
    }
</style>


</div></div></div>
<!-- <div class="flex-grow-1"></div> -->

    <div class=" ">
        <div class="app-footer pb-0">
            <div class="footer-bottom border-top pt-3 d-flex flex-column justify-content-center flex-sm-row align-items-center">
                <p class="com" style="font-size: 16px; color: white; font-weight: 900;color: white;"> <a href="#"><span style="color: white;">Designed & Developed By Comtranse Technology, Kolhapur </span></a> 2024 </p>
            </div>
        </div>
    </div>
</div>
</div>
            <!-- fotter end -->
        </div> 
    </div>
   


 <script>
        // $(window).on('load', function () {
        //     $('.loader_circle').fadeOut();
        // });

    $(document).ready(function () {
      $('.loader_circle').fadeOut();
    });
   </script>


<script>
        // Wait for the page to fully load
        window.addEventListener("load", function () {
            // Get the preloader element
            var preloader = document.querySelector(".preloader-wrapper");

            // Hide the preloader after 2 seconds
            setTimeout(function () {
                preloader.style.display = "none";
            }, 400); // 2000 milliseconds = 2 seconds
        });
    </script>

    <!-- <script src="<?=base_url();?>Assets/js/plugins/jquery-3.3.1.min.js"></script> -->
    <script src="<?=base_url();?>Assets/js/plugins/bootstrap.bundle.min.js"></script>
    <script src="<?=base_url();?>Assets/js/plugins/perfect-scrollbar.min.js"></script>
    <script src="<?=base_url();?>Assets/js/scripts/script.min.js"></script>
    <script src="<?=base_url();?>Assets/js/scripts/sidebar.large.script.min.js"></script>
    <script src="<?=base_url();?>Assets/js/plugins/echarts.min.js"></script>
    <script src="<?=base_url();?>Assets/js/scripts/echart.options.min.js"></script>
    <script src="<?=base_url();?>Assets/js/scripts/dashboard.v1.script.min.js"></script>
    <script src="<?=base_url();?>Assets/js/scripts/dashboard.v1.script.min.js"></script>
    <!-- ***** Added New Scripts*********** -->
      <!--This page JavaScript -->
     
      <script src="<?php echo base_url(); ?>Assets/css/datatables.min.js"></script>
      <script src="<?php echo base_url(); ?>Assets/js/sweetalert.min.js"></script>


</body>



</html>